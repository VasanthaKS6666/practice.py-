name = "varsha"
age = "19" 
is_student = True #bool
weight = 49.50
s="100"
age_float=float(age)
print(float(age))
print(int(s)+int(age))

