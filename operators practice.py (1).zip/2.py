name = "varsha"
age = "19" #int
is_student = True #bool
weight = 49.50
print(name)
print(type(weight))

