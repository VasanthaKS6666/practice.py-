a="varsha"
b="guna"
c="gagan"
a,b,c=b,c,a
print("a=",a)
print("b=",b)
print("c=",c)
